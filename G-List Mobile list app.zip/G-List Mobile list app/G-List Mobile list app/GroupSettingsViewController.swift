//
//  GroupSettingsViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 2/3/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class GroupSettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
        
        @IBOutlet weak var groupNameTextField: UITextField!
        
        @IBOutlet weak var descriptionLabel: UILabel!
        
        @IBOutlet weak var descriptionTextView: UITextView!
        
        @IBOutlet weak var groupImageImageView: UIImageView!
        
        @IBOutlet weak var membersTableView: UITableView!
        
        @IBOutlet weak var membersTableViewConstraint: NSLayoutConstraint!
    
        @IBOutlet weak var amountOfMembers: UILabel!
        
        @IBOutlet weak var mainScrollView: UIScrollView!
        
        var passedGroup = Group()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            makeInverseGradient()
            
            membersTableView.dataSource = self
            membersTableView.delegate = self
            
            groupNameTextField.delegate = self
            
            descriptionTextView.delegate = self
            
            membersTableView.scrollEnabled = false
            membersTableView.userInteractionEnabled = true
            
            groupNameTextField.text! = passedGroup.groupName
            descriptionTextView.text! = passedGroup.groupDescription
            groupImageImageView.image = passedGroup.groupImage
            
            
            if view.bounds.width == 320 && view.bounds.height == 480 { //4s
                
                if passedGroup.members.count > 2 {
                    
                    mainScrollView.scrollEnabled = true
                    mainScrollView.bounces = true
                }else{
                    mainScrollView.scrollEnabled = false
                }
                
            }else if view.bounds.width == 320 && view.bounds.height == 568 { //5
                
                if passedGroup.members.count > 4 {
                    
                    mainScrollView.scrollEnabled = true
                    mainScrollView.bounces = true
                }else{
                    mainScrollView.scrollEnabled = false
                }
                
                
            }else if view.bounds.width == 375.0 && view.bounds.height == 667.0{ //6
                
                if passedGroup.members.count > 6 {
                    
                    mainScrollView.scrollEnabled = true
                    mainScrollView.bounces = true
                }else{
                    mainScrollView.scrollEnabled = false
                }
                
                
            }else if view.bounds.width == 414.0 && view.bounds.height == 736.0 { //6+
                
                if passedGroup.members.count > 8 {
                    
                    mainScrollView.scrollEnabled = true
                    mainScrollView.bounces = true
                }else{
                    mainScrollView.scrollEnabled = false
                }
                
                
            }
            
        }
        
        
        func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            amountOfMembers.text! = "\(passedGroup.members.count) members"
            membersTableViewConstraint.constant = (CGFloat(passedGroup.members.count * 40))
            
            return passedGroup.members.count
        }
        
        func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            let cell = membersTableView.dequeueReusableCellWithIdentifier("memebrcell") as! MemeberTableViewCell
            if passedGroup.members[indexPath.row] == PFUser.currentUser()!.username!{
                cell.mainLabel.text = "You"
            }else{
                cell.mainLabel.text = passedGroup.members[indexPath.row]
            }
            return cell
        }
        
        func imagetapped(){
            //if camera is available then select the image
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
                let cameraViewC = UIImagePickerController()
                
                cameraViewC.sourceType = UIImagePickerControllerSourceType.Camera
                cameraViewC.delegate = self
                
                self.presentViewController(cameraViewC, animated: true, completion: nil)
                
                
            }
        }
        
        func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
            
            passedGroup.groupImage = image
            groupImageImageView.image = passedGroup.groupImage
            picker.dismissViewControllerAnimated(true, completion: nil)
            
        }
        
        @IBAction func changeImageTapped(sender: AnyObject) {
            imagetapped()
        }
        
        @IBAction func addMembersTapped(sender: AnyObject) {
            
            performSegueWithIdentifier("GroupSettingsToNewGroupTwo", sender: self)
        }
        
        
        @IBAction func backButtonTapped(sender: AnyObject) {
            performSegueWithIdentifier("groupSettingsToMainGroup", sender: "")
        }
        
        
        override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
            if segue.identifier == "GroupSettingsToNewGroupTwo" { //members screen
                
                let nextviewcontroller = segue.destinationViewController as! NewGroupSecondViewController
                nextviewcontroller.youmightneedthis = passedGroup
                nextviewcontroller.boolz = true
                
            }else{
                
                let nextviewcontroller = segue.destinationViewController as! GroupViewController
                nextviewcontroller.selectedGroup = passedGroup
                
                
                
                
                
            }
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "remove") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "delete")
        }
        delete.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        let none = UITableViewRowAction(style: .Normal, title: "") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "none")
        }
        none.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        
        
        if passedGroup.members[indexPath.row] == PFUser.currentUser()!.username!{
            return [none]
        }else{
            return [delete]
        }
        
    }

    
    
    func doAction(tableView: UITableView, indexPath: NSIndexPath, type: String) {
        
        if type == "delete" {
            
            passedGroup.members.removeAtIndex(indexPath.row)
            membersTableView.reloadData()
            
        }else if type == "none" {
            
            
            
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        
        func textFieldDidEndEditing(textField: UITextField) {
            passedGroup.groupName = groupNameTextField.text!
        }
        
        func textFieldShouldReturn(textField: UITextField) -> Bool {
            groupNameTextField.resignFirstResponder()
            return true
        }
        
        func textViewDidEndEditing(textView: UITextView) {
            passedGroup.groupDescription = descriptionTextView.text
        }
        
        func textViewDidChange(textView: UITextView) {
            if textView.text.containsString("\n") {
                descriptionTextView.resignFirstResponder()
            }
        }
        
        func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
            return textView.text.characters.count + (text.characters.count - range.length) <= 30
        }
        
        func makeInverseGradient(){
            
            let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
            
            let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
            
            let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
            
            let gradientLocations: [Float] = [0.0,1.0]
            
            let gradientLayer: CAGradientLayer = CAGradientLayer()
            gradientLayer.colors = gradientColors
            gradientLayer.locations = gradientLocations
            
            gradientLayer.frame = self.view.bounds
            self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
            
        }
}
