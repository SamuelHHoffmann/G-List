//
//  NewGroupSecondViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/16/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI
import Parse


class NewGroupSecondViewController: UIViewController, CNContactPickerDelegate, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UIScrollViewDelegate {

    @IBOutlet weak var mainScrollView: UIScrollView!
    
    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var secondaryConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var peopleTableView: UITableView!
    
    
    @IBOutlet weak var openContactsButton: UIButton!
    
    @IBOutlet weak var usernameTableView: UITableView!
    @IBOutlet weak var tableViewConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var addMembersLabel: UILabel!
    
    var memebers : [String] = []
    
    var tempMembers : [String] = []

    var passedImage = UIImage()
    
    var passedName = ""
    
    var boolz = false
    
    var youmightneedthis = Group()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        openContactsButton.enabled = false
        
        peopleTableView.delegate = self
        peopleTableView.dataSource = self
        
        usernameTableView.delegate = self
        usernameTableView.dataSource = self
        
        usernameTextField.delegate = self
        
        usernameTableView.scrollEnabled = false
        usernameTableView.userInteractionEnabled = true
        
        peopleTableView.scrollEnabled = false
        peopleTableView.userInteractionEnabled = false
        
        mainScrollView.delegate = self
        
        if boolz == true {
            memebers = youmightneedthis.members
            memebers.removeAtIndex(memebers.indexOf(PFUser.currentUser()!.username!)!)
        
        }
        
        if view.bounds.width == 320 && view.bounds.height == 480 { //4s
            
            if memebers.count > 2 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
        }else if view.bounds.width == 320 && view.bounds.height == 568 { //5
            
            if memebers.count > 4 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
                
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }else if view.bounds.width == 375.0 && view.bounds.height == 667.0{ //6
            
            if memebers.count > 6 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }else if view.bounds.width == 414.0 && view.bounds.height == 736.0 { //6+
            
            if memebers.count > 8 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }
        
        
        
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        tableViewConstraint.constant = CGFloat(memebers.count * 40)
        
        secondaryConstraint.constant = CGFloat(tempMembers.count * 40)
        
        if memebers.count > 8 {
            
            mainScrollView.bounces = true
            
        }else{
            mainScrollView.bounces = false
        }
        var num = 0
        if tableView == peopleTableView {
            
            num = memebers.count
        }
        if tableView == usernameTableView {
            
            num = tempMembers.count
        }
        return num
        
    }
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if tableView == usernameTableView {
            
            memebers.append(tempMembers[indexPath.row])
            tempMembers = []
            usernameTextField.resignFirstResponder()
            peopleTableView.reloadData()
            
        }
    }
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if tableView == peopleTableView {
            let cell = peopleTableView.dequeueReusableCellWithIdentifier("memberCell") as! MemeberTableViewCell
            cell.mainLabel.text = memebers[indexPath.row]
            //cell.userInteractionEnabled = false
            return cell
        }else if tableView == usernameTableView {
            let cell = peopleTableView.dequeueReusableCellWithIdentifier("memberCell") as! MemeberTableViewCell
            cell.mainLabel.text = tempMembers[indexPath.row]
            //cell.userInteractionEnabled = true
            return cell
        }else{
            let cell = peopleTableView.dequeueReusableCellWithIdentifier("memberCell") as! MemeberTableViewCell
            return cell
        }
        
        
        
    }
    
    
    
    func textFieldDidEndEditing(textField: UITextField) {
        tempMembers = []
        
        let query = PFQuery(className: "_User")
        
        query.whereKey("username", containsString: usernameTextField.text)
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                for index in objects!{
                    
                    self.addItem(index as! PFObject)
                    
                }
            }
            self.usernameTableView.reloadData()
        }
        
        
    }
    
    func addItem(index:PFObject){
        
        let tempString = index.valueForKey("username") as! String
        
        if tempString == PFUser.currentUser()!.username! {
            
        }else{
            
            tempMembers.append(tempString)
        
        }
    }
    
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        usernameTextField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        addMembersLabel.text = "Add Members:"
        addMembersLabel.textColor = UIColor(colorLiteralRed: 21/255, green: 141/255, blue: 11/255, alpha: 1)
        
    }
    
    
    
    
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        if boolz == false {
            performSegueWithIdentifier("newgroupsecondtofirst", sender: self)//need to make segues
        }else{
            performSegueWithIdentifier("newGroupTwotoGroupSetings", sender: self)
        }
    }
    
    
    @IBAction func continueButtonTapped(sender: AnyObject) {
        if memebers.count > 0 {
            self.memebers.append(PFUser.currentUser()!.username!)
            if boolz == false {
                
                performSegueWithIdentifier("newgroupsecondtothird", sender: self)//need to make segues
            }else{
                
                performSegueWithIdentifier("newGroupTwotoGroupSetings", sender: self)
            }
        }else{
            addMembersLabel.text = "You must have at least 1 member in your group!"
            addMembersLabel.textColor = UIColor.redColor()
        }
    }
    
    
    @IBAction func openContactsButtonTapped(sender: AnyObject) {
        showContacts()
    }
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
        if segue.identifier == "newgroupsecondtothird" {
            
            let nextViewController = segue.destinationViewController as! NewGroupThirdViewController
            
            nextViewController.passedName2 = passedName
            nextViewController.passedImage2 = passedImage
            nextViewController.passedMemberList = memebers
        }
        
        if segue.identifier == "newgroupsecondtofirst" {
            let nextViewController = segue.destinationViewController as! NewGroupFirstViewController
            
            nextViewController.name = passedName
            nextViewController.image1 = passedImage
        }
        
        if segue.identifier == "newGroupTwotoGroupSetings" {
            
            let nextviewcontroller = segue.destinationViewController as! GroupSettingsViewController
           
            self.memebers.append(PFUser.currentUser()!.username!)
            youmightneedthis.members = memebers
            
            nextviewcontroller.passedGroup = youmightneedthis
            
        }
        
        
    }
    
    
    
    
    
    
    
    
    
    
    func showContacts() {
        let contactPickerViewController = CNContactPickerViewController()
        
        contactPickerViewController.delegate = self
        
        presentViewController(contactPickerViewController, animated: true, completion: nil)
    }
    
    func contactPicker(picker: CNContactPickerViewController, didSelectContact contact: CNContact) {
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "remove") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "delete")
        }
        delete.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        if tableView == usernameTableView {
            return []
        }else{
            return [delete]
        }
        
    }
    
    
    
    func doAction(tableView: UITableView, indexPath: NSIndexPath, type: String) {
        
        if type == "delete" {
            
            memebers.removeAtIndex(indexPath.row)
            
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    func makeInverseGradient(){
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }

}
