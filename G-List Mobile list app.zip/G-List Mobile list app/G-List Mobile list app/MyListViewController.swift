//
//  MyListViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/29/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class MyListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var mainTableView: UITableView!
    
    @IBOutlet weak var mylistlabel: UILabel!
    
    var groups : [Group] = []
    
    var totalAmount = 0
    
    var items : [Item] = []
    
    var arr : [Item] = []
    
     var refreshControl : UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        mainTableView.dataSource = self
        mainTableView.delegate = self
        
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
        self.mainTableView.addSubview(refreshControl)
        
        refreshGroups(true)
        
        // Do any additional setup after loading the view.
    }
    
    func refresh(sender:AnyObject)
    {
        refreshGroups(true)
        refreshControl.endRefreshing()
    }
    
    
    func refreshGroups(type: Bool){
        
        mylistlabel.text = "Checking..."
        
         groups = []
        
         totalAmount = 0
        
         items  = []
        
        
        let query = PFQuery(className: "Group")
        
        query.whereKey("creator", equalTo: PFUser.currentUser()!.username!)
        
        
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                var counter : Int = 0
                for index in objects!{
                    //(index as! PFObject).pin()      //pining saves the object in offline parse db
                    //the offline parse db is created automatically
                    
                    counter++
                    self.mylistlabel.text = "Finding Groups..."
                    
                    self.makeGroups(index as! PFObject, type: type, Num: counter)
                    
                    if counter == query.countObjects() {
                       
                    }
                }
            }
        }
    }
    
    
    
    
    func makeArray(index:PFObject, NUM2: Int){
        
        
        
        let item = Item()
        item.objectId = index.valueForKey("objectId") as! String
        item.name = index.valueForKey("name") as! String
        item.descrpiton = index.valueForKey("descrpiton") as! String
        item.group = index.valueForKey("group") as! String
        item.gotten = index.valueForKey("gotten") as! Bool
        item.rejected = index.valueForKey("rejected") as! Bool
        item.sender = index.valueForKey("sender") as! String
        item.quantity = index.valueForKey("quantity") as! Int
        
        arr.append(item)
        
        
        
    }
    
    
    
    func makeGroups(index:PFObject, type: Bool, Num: Int){
        
        self.mylistlabel.text = "Creating Group..."
        
        let selectedGroup = Group()
        
        selectedGroup.objectId = index.valueForKey("objectId") as! String
        selectedGroup.creator = index.valueForKey("creator") as! String
        selectedGroup.editable = index.valueForKey("editable") as! Bool
        selectedGroup.groupDescription = index.valueForKey("groupDescription") as! String
        //self.selectedGroup.groupImage = index("groupImage") as! UIImage
        
        
        
        
        
        let query2 = PFQuery(className: "Item")
        
        query2.whereKey("group", equalTo: selectedGroup.objectId)
        
        
        query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                self.arr = []
                var counter2 : Int = 0
                for index in objects!{
                    //(index as! PFObject).pin()      //pining saves the object in offline parse db
                    //the offline parse db is created automatically
                    counter2++
                   
                    self.mylistlabel.text = "Finding Items..."
                    
                    self.makeArray(index as! PFObject, NUM2: counter2)
                    if counter2 == query2.countObjects() {
                        
                        self.mylistlabel.text = "My List"
                    }
                }
                self.mylistlabel.text = "My List"
            }
            
            
            selectedGroup.itemList = self.arr
            
            selectedGroup.groupName = index.valueForKey("groupName") as! String
            selectedGroup.members = index.valueForKey("members") as! [String]
            
            self.groups.append(selectedGroup)
            
            
            
            
           
            
            if self.groups.count > 0 {
                
               
                
                self.items = []
                
                for joe in self.groups {
                    
                    if joe.itemList.count > 0 {
                        
                        if type == true {
                            
                            var hasGood = false
                            
                            for bob in joe.itemList {
                                
                                if bob.gotten == false && bob.rejected == false {
                                    hasGood = true
                                }
                            }
                            
                            if hasGood == true {
                                
                                let newItem = Item()
                                newItem.name = joe.groupName
                                newItem.descrpiton = "..........................................................."
                                
                                self.items.append(newItem)
                                
                                
                                for bob in joe.itemList {
                                    
                                    if bob.gotten == false && bob.rejected == false {
                                        self.items.append(bob)
                                        
                                        
                                    }
                                }
                                hasGood = false
                                
                            }
                            
                            
                        }else{
                            
                            let newItem = Item()
                            newItem.name = joe.groupName
                            newItem.descrpiton = "..........................................................."
                            
                            self.items.append(newItem)
                            
                            
                            self.items.appendContentsOf(joe.itemList)
                            
                        }
                        
                        self.mainTableView.reloadData()
                    }
                }
             
            }
            
        }
    }
    
    
    
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        
        if items.count == 0 {
            mainTableView.alpha = 0
            
        }else{
            mainTableView.alpha = 1
        }
        
        return items.count
    
    }
    
    
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        if items[indexPath.row].descrpiton == "..........................................................." {
            
            let cell = mainTableView.dequeueReusableCellWithIdentifier("sepperatorCell") as! seperatorCell
            
            cell.sepperatorName.text = items[indexPath.row].name
            
            return cell
            
        }else{
         
            let cell = mainTableView.dequeueReusableCellWithIdentifier("Mylistcell") as! MyListCell
            
            cell.itemName.text = "\(items[indexPath.row].quantity) (of) \(items[indexPath.row].name)"
            cell.itemDescription.text = items[indexPath.row].descrpiton
            
            
                let query = PFQuery(className: "_User")
                
                query.whereKey("username", equalTo: items[indexPath.row].sender)
                
                query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                    if error == nil && objects != nil{
                        let obj = (objects as! [PFObject]).first!
                        
                        let file = obj.objectForKey("UserImage") as! PFFile
                        
                        
                        cell.userImageView.image = UIImage(data: file.getData()!)
                        
                        
                    }
                }
            
            
            if items[indexPath.row].gotten == true {
                cell.checkImageView.image = UIImage(named: "Path 48")
            }else{
                cell.checkImageView.image = UIImage(named: "Rectangle 82")
            }
            
            return cell
        }
        
    }
    
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let selectedItem = items[indexPath.row]
        selectedItem.gotten = true
        tableView.reloadData()
        
        let query = PFQuery(className: "Item")
        
        query.whereKey("objectId", equalTo: selectedItem.objectId)
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                let obj = (objects as! [PFObject]).first!
                
                obj.setValue(true, forKey: "gotten")
                obj.saveInBackground()
                
            }
        }
    
    
    
    
    }
    
    
    
    
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if items[indexPath.row].descrpiton == "..........................................................." {
            
            return 25
            
        }else{
            
            return 75
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
    
        performSegueWithIdentifier("mylisttomain", sender: self)
    
    
    }
    
    
    
    func makeInverseGradient(){
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    

}
