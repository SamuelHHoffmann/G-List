//
//  Group.swift
//  G-List Mobile list app
//
//  Created by Samuel Hoffmann on 12/22/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import Foundation
import Parse

class Group {
    
    var groupName = ""
    
    var groupDescription = ""
    
    var members : [String] = []
    
    var editable = false
    
    var groupImage = UIImage()
    
    var itemList : [Item] = []
    
    var creator = ""
    
    var objectId = ""
    
}

