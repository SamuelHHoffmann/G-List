//
//  FirstInfoViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/25/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse




class FirstInfoViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageLabel: UILabel!
    
    @IBOutlet weak var userImage: UIImageView!
    
    @IBOutlet weak var usernametextField: UITextField!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    var name = ""
    
    var image1 = UIImage(named: "images")
    
    
    @IBAction func contiuneButtonTapped(sender: AnyObject) {
    
        if usernametextField.text?.characters.count < 6 {
            //alert must be longer than 6 chars
            usernameLabel.text = "must be 6 letters long"
            usernameLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
            //shake screen
            
        }else if usernamedoesExsists(usernametextField.text!) {
            
            usernameLabel.text = "username allllready exsists"
            usernameLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
            //shake screen
            
        }else{ //all is good
            
            
            performSegueWithIdentifier("firsttosecond", sender: self)
        }
    
    }
    
    
    func randomResponses(){
        let string1 = "Are you sure about THAT image?"
        let string2 = "Whoa, just whoa."
        let string3 = "Nice pic dude."
        let string4 = "You know, if you tap again you can change that."
        let string5 = "No comment..."
        let string6 = "You know other people can see that, right?"
        let string7 = "That's a cool profile picture."
        let string8 = "Just some friendly advice..."
        let string9 = "Some people were just not meant to have profile pictures."
        
        let randomNumber = Int(arc4random_uniform(9) + 1)
        
        if randomNumber == 1 {
            imageLabel.text = string1
        }else if randomNumber == 2 {
            imageLabel.text = string2
        }else if randomNumber == 3 {
            imageLabel.text = string3
        }else if randomNumber == 4 {
            imageLabel.text = string4
        }else if randomNumber == 5 {
            imageLabel.text = string5
        }else if randomNumber == 6 {
            imageLabel.text = string6
        }else if randomNumber == 7 {
            imageLabel.text = string7
        }else if randomNumber == 8 {
            imageLabel.text = string8
        }else if randomNumber == 9 {
            imageLabel.text = string9
        }
    }
    
    
    
    
    @IBAction func loginButtonTapped(sender: AnyObject) {
        
        NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isNotFirstTime")
        performSegueWithIdentifier("firsttosecond", sender: self)
        
    }
    
    
    
    
    
    
    
    
    
    
    func usernamedoesExsists(name: String) -> Bool{
        var returnBool = false
        
        let query = PFQuery(className: "_User")
        
        query.whereKey("username", equalTo: usernametextField.text!)
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil{
                
                if objects != nil {
                    returnBool = false
                }else{
                    returnBool = true
                }
            }
        }
        
        return returnBool
    }
    
    
    
    
    override func viewWillAppear(animated: Bool) {
        
        userImage.layer.cornerRadius = 224/2
        userImage.clipsToBounds = true
        
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeGradient()
        
        userImage.image = image1
        usernametextField.text = name
        
        
        let ImageTapped = UITapGestureRecognizer(target: self, action: "imageTapped")
        
        userImage.addGestureRecognizer(ImageTapped)
        
        usernametextField.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    
    func imageTapped(){
        //if camera is available then select the image
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            let cameraViewC = UIImagePickerController()
            cameraViewC.sourceType = UIImagePickerControllerSourceType.Camera
            cameraViewC.delegate = self
            
            self.presentViewController(cameraViewC, animated: true, completion: nil)
            
            
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        
        userImage.image = image
        randomResponses()
        picker.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        usernametextField.resignFirstResponder()
        return true
        
    }

    
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        //if segue == "firsttosecond" {
            let secondViewController = segue.destinationViewController as! SecondInfoViewController
        
            secondViewController.image1 = userImage.image!
            secondViewController.userName1 = usernametextField.text!
        //}
    
        
    }
    
    
    
}
