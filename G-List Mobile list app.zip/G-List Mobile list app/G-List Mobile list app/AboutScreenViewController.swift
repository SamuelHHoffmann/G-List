//
//  AboutScreenViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/29/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import MessageUI
import Parse

class AboutScreenViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MFMailComposeViewControllerDelegate {

    
    @IBOutlet weak var tableViewThingy: UITableView!
    
    @IBOutlet weak var tableviewconstraint: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeGradient()
        
        tableViewThingy.delegate = self
        tableViewThingy.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableviewconstraint.constant = 40
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableViewThingy.dequeueReusableCellWithIdentifier("joe") as! MemeberTableViewCell
        cell.mainLabel.text = "Email"
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        tableViewThingy.deselectRowAtIndexPath(indexPath, animated: true)
        
        let picker = MFMailComposeViewController()
        picker.mailComposeDelegate = self
        
        picker.setToRecipients(["glist.generalinquiries@gmail.com"])
        picker.setSubject("Username: \(PFUser.currentUser()!.username!)")
        
        presentViewController(picker, animated: true, completion: nil)
        
    }
    
    
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func backbuttontapped(sender: AnyObject) {
        performSegueWithIdentifier("abouttomain", sender: self)
    }
    
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    
    

}
