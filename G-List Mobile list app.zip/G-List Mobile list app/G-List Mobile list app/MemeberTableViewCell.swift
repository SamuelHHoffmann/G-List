//
//  MemeberTableViewCell.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/21/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit

class MemeberTableViewCell: UITableViewCell {

    
    @IBOutlet weak var mainLabel: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
