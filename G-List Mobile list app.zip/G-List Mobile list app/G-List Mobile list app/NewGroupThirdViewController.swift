//
//  NewGroupThirdViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/27/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse


class NewGroupThirdViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    @IBOutlet weak var groupNameTextField: UITextField!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var groupImageImageView: UIImageView!
    
    @IBOutlet weak var membersTableView: UITableView!
    
    @IBOutlet weak var membersTableViewConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var amountOfMembers: UILabel!
    
    @IBOutlet weak var mainScrollView: UIScrollView!
    
    
    var passedName2 = "Group Name"
    
    var groupDescription = ""
    
    var passedImage2 = UIImage()
    
    var passedMemberList : [String] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        membersTableView.dataSource = self
        membersTableView.delegate = self
        
        groupNameTextField.delegate = self
        
        descriptionTextView.delegate = self
        
        membersTableView.scrollEnabled = false
        membersTableView.userInteractionEnabled = true
        
        groupNameTextField.text! = passedName2
        descriptionTextView.text! = groupDescription
        groupImageImageView.image = passedImage2
        
        
        if view.bounds.width == 320 && view.bounds.height == 480 { //4s
            
            if passedMemberList.count > 2 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
        }else if view.bounds.width == 320 && view.bounds.height == 568 { //5
            
            if passedMemberList.count > 4 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
                
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }else if view.bounds.width == 375.0 && view.bounds.height == 667.0{ //6
            
            if passedMemberList.count > 6 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }else if view.bounds.width == 414.0 && view.bounds.height == 736.0 { //6+
            
            if passedMemberList.count > 8 {
                
                mainScrollView.scrollEnabled = true
                mainScrollView.bounces = true
            }else{
                mainScrollView.scrollEnabled = false
            }
            
            
        }
        
    }

    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        amountOfMembers.text! = "\(passedMemberList.count) members"
        membersTableViewConstraint.constant = (CGFloat(passedMemberList.count * 40))
        
        return passedMemberList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = membersTableView.dequeueReusableCellWithIdentifier("memebrcell") as! MemeberTableViewCell
        if passedMemberList[indexPath.row] == PFUser.currentUser()!.username!{
            cell.mainLabel.text = "You"
        }else{
            cell.mainLabel.text = passedMemberList[indexPath.row]
        }
        return cell
    }
    
    func imagetapped(){
        //if camera is available then select the image
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            let cameraViewC = UIImagePickerController()
            
            cameraViewC.sourceType = UIImagePickerControllerSourceType.Camera
            cameraViewC.delegate = self
            
            self.presentViewController(cameraViewC, animated: true, completion: nil)
            
            
        }
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        
        passedImage2 = image
        groupImageImageView.image = passedImage2
        picker.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    @IBAction func changeImageTapped(sender: AnyObject) {
        imagetapped()
    }

    @IBAction func addMembersTapped(sender: AnyObject) {
        performSegueWithIdentifier("newgroupthirdtosecond", sender: self)
    }
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        performSegueWithIdentifier("newgroupthirdtosecond", sender: self)
    }
    
    
    @IBAction func createButtonTapped(sender: AnyObject) {
        
        let newGroup = PFObject(className: "Group")
        
        newGroup.setObject(PFUser.currentUser()!.username!, forKey: "creator")
        newGroup.setObject(passedName2, forKey: "groupName")
        newGroup.setObject(groupDescription, forKey: "groupDescription")
        newGroup.setObject(true, forKey: "editable")
        newGroup.setObject(passedMemberList, forKey: "members")
        newGroup.setObject(PFUser.currentUser()!.username!, forKey: "objectId2")
        newGroup.ACL?.setPublicReadAccess(true)
        newGroup.ACL?.setPublicWriteAccess(true)
        newGroup.setValue(1, forKey: "value")
        
        let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(passedImage2)!)
        
        newGroup.setObject(file, forKey: "groupImage")
        
        if newGroup.save() == true {
            performSegueWithIdentifier("newgroupthirdtomain", sender: self)
        }else{
            
        }
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "newgroupthirdtosecond" { //back button
            
            let nextviewcontroller = segue.destinationViewController as! NewGroupSecondViewController
            nextviewcontroller.passedName = passedName2
            nextviewcontroller.passedImage = passedImage2
            nextviewcontroller.memebers = passedMemberList
            
        }
    }
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "remove") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "delete")
        }
        delete.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        let none = UITableViewRowAction(style: .Normal, title: "") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "none")
        }
        none.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        
        
        if passedMemberList[indexPath.row] == PFUser.currentUser()!.username! {
            return [none]
        }else{
            return [delete]
        }
        
    }
    
    
    
    func doAction(tableView: UITableView, indexPath: NSIndexPath, type: String) {
        
        if type == "delete" {
            
            passedMemberList.removeAtIndex(indexPath.row)
            membersTableView.reloadData()
            
        }else if type == "none" {
            
            
            
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func textFieldDidEndEditing(textField: UITextField) {
        passedName2 = groupNameTextField.text!
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        groupNameTextField.resignFirstResponder()
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        groupDescription = descriptionTextView.text
    }
    
    func textViewDidChange(textView: UITextView) {
        if textView.text.containsString("\n") {
            descriptionTextView.resignFirstResponder()
        }
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        return textView.text.characters.count + (text.characters.count - range.length) <= 30
    }
    
    func makeInverseGradient(){
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    
    
}
