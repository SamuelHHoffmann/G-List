//
//  Item.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/29/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import Foundation
import Parse 

class Item {
    
    var name = ""
    
    var descrpiton = ""
    
    var sender = ""
    
    var gotten = false
    
    var rejected = false
    
    var objectId = ""
    
    var group = ""
    
    var quantity = 0
}