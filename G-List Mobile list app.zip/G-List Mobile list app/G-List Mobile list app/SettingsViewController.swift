//
//  SettingsViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/11/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class SettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var maintableview: UITableView!
    
    var mainArray : [String] = ["Sign Out", "Play Demo", "User Info"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        maintableview.delegate = self
        maintableview.dataSource = self
        
        // Do any additional setup after loading the view.
    }

    
    @IBAction func backTapped(sender: AnyObject) {
        
        performSegueWithIdentifier("setingstomain", sender: self)
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mainArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = maintableview.dequeueReusableCellWithIdentifier("lol") as! MemeberTableViewCell
        
        cell.mainLabel.text = mainArray[indexPath.row]
        
        if indexPath.row == 0 {//1
            
            cell.mainLabel.textColor = UIColor(red: 110/255, green: 29/255, blue: 35/255, alpha: 1)
            
        }else if indexPath.row == 1 {//2
        
            cell.mainLabel.textColor = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 1)
            
        }else if indexPath.row == 2 {//3
            
            cell.mainLabel.textColor = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 1)
            
        }
        
        
        
        return cell
        
        
    }
    
    
//    if NSUserDefaults.standardUserDefaults().boolForKey("userIsSaved") == true {
//    
//    PFUser.logInWithUsernameInBackground(NSUserDefaults.standardUserDefaults().stringForKey("savedUsername")!, password: NSUserDefaults.standardUserDefaults().stringForKey("savedPassword")!, block: { (user, error) -> Void in
//    
//    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if indexPath.row == 0 {
            
            
            PFUser.logOut()
            NSUserDefaults.standardUserDefaults().setValue(false, forKey: "isNotFirstTime")
            NSUserDefaults.standardUserDefaults().setValue(false, forKey: "userIsSaved")
            NSUserDefaults.standardUserDefaults().setValue("", forKey: "savedPassword")
            NSUserDefaults.standardUserDefaults().setValue("", forKey: "savedUsername")
            performSegueWithIdentifier("settingstoload", sender: self)
            
            
        }else if indexPath.row == 1 {
            
            performSegueWithIdentifier("settingstodemo", sender: self)
            
            
            
        }else if indexPath.row == 2 {
            
            performSegueWithIdentifier("settignstoinfo", sender: self)
            
            
            
        }
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "settingstodemo" {
            
            let next = segue.destinationViewController as! DemoScreenViewController
            next.boolx = true
            
        }
    }
    
    
    
    
    func makeInverseGradient(){
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }

}
