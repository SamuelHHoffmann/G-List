//
//  SecondInfoViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/26/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class SecondInfoViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var mainBox: UIImageView!
    
    @IBOutlet weak var checkmarkImageView: UIImageView!

    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordLabel: UILabel!
    
    @IBOutlet weak var passwordTetxField: UITextField!
    
    @IBOutlet weak var secondaryButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    
    var image1 = UIImage()
    
    var userName1 = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeGradient()
        
        
        emailTextField.delegate = self
        passwordTetxField.delegate = self
        
        
        if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
            
            loginButton.setTitle("Sign Up", forState: UIControlState.Normal)
            secondaryButton.setTitle("Log In?", forState: UIControlState.Normal)
            
            
        }else{
            
            
            secondaryButton.setTitle("Sign Up?", forState: UIControlState.Normal)
            loginButton.setTitle("Log In", forState: UIControlState.Normal)
            emailLabel.text = "Username"
            passwordLabel.text = "Password"
            
            
        }
        
        
        let tappedGesture = UITapGestureRecognizer(target: self, action: "checkmarkClicked")
        
        
        checkmarkImageView.addGestureRecognizer(tappedGesture)
        
        
        
        
    }
    
    
    @IBAction func secondaryButtonTapped(sender: AnyObject) {
        
     
        
        if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
            
            NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isNotFirstTime")
            performSegueWithIdentifier("secondtoload", sender: self)
            
            
        }else{
            
            NSUserDefaults.standardUserDefaults().setBool(false, forKey: "isNotFirstTime")
            performSegueWithIdentifier("secondtoload", sender: self)
            
        }
        
        
    }
    
    
    var isChecked = true
    
    func checkmarkClicked(){
        
        if isChecked == true {
            checkmarkImageView.image = UIImage(named: "Path 48")
            isChecked = false
        }else{
            checkmarkImageView.image = UIImage(named: "Rectangle 82")
            isChecked = true
        }
        
    }
    
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        
        if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
            
            performSegueWithIdentifier("secondtofirst", sender: self)
            
        }else{
            
            performSegueWithIdentifier("secondtoload", sender: self)
            
        }
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "secondtofirst" {
            
            if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
                
                let nextViewController = segue.destinationViewController as! FirstInfoViewController
                
                nextViewController.name = userName1
                nextViewController.image1 = image1
                
            }
        }
    }
    
    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.drawInRect(CGRectMake(0, 0, newSize.width, newSize.height))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
    
    
    var isgood = false
    
    @IBAction func loginButtonTapped(sender: AnyObject) {
        
        if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
            
            if emailTextField.text! == "" {
                //error
                emailLabel.text = "Please enter an email address"
                emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if isGoodEmail(emailTextField.text!) == false {
                //error
                emailLabel.text = "must be a valid email address"
                emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if passwordTetxField.text! == "" {
                //error
                passwordLabel.text = "Please enter a Password"
                passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if passwordTetxField.text?.characters.count < 8 {
                //error
                passwordLabel.text = "Password must be 8 or more letters"
                passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else{
                
                let newUser = PFUser()
                newUser.email = emailTextField.text
                newUser.password = passwordTetxField.text
                
                
                image1 = imageWithImage(image1, scaledToSize: CGSize(width: 75, height: 75))
                
                let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(image1)!)
                
                newUser.setValue(file, forKey: "UserImage")
                
               
                
                
                newUser.username = userName1
                
                if isChecked == true {
                    NSUserDefaults.standardUserDefaults().setBool(true, forKey: "userIsSaved")
                    
                    NSUserDefaults.standardUserDefaults().setValue(userName1, forKey: "savedUsername")
                    NSUserDefaults.standardUserDefaults().setValue(passwordTetxField.text, forKey: "savedPassword")
                    
                }else{
                    //just do nothing
                    NSUserDefaults.standardUserDefaults().setBool(false, forKey: "userIsSaved")
                }
                
                newUser.signUpInBackgroundWithBlock { (succeeded: Bool, error: NSError?) -> Void in
                
                    if let error = error {
                        
                        
                        
                        
                        if "\(error)" == "Error Domain=Parse Code=202 \"username \(self.userName1) already taken\" UserInfo={code=202, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=username \(self.userName1) already taken, NSLocalizedDescription=username \(self.userName1) already taken}" {
                            
                            self.passwordLabel.text = "The Username entered in the previous screen is allready taken please choose another one."
                            self.passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                            
                        }else if "\(error)" == "Error Domain=Parse Code=203 \"the email address \(self.emailTextField.text!) has already been taken\" UserInfo={code=203, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=the email address \(self.emailTextField.text!) has already been taken, NSLocalizedDescription=the email address \(self.emailTextField.text!) has already been taken}" {
                            
                            self.emailLabel.text = "This email is allready in use. please login or enter another email."
                            self.emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                            
                        }else if "\(error)" == "Error Domain=Parse Code=125 \"invalid email address\" UserInfo={code=125, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=invalid email address, NSLocalizedDescription=invalid email address}" {
                            
                            self.emailLabel.text = "Invalid Email, please enter a valid email"
                            self.emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                            
                        }else{
                            
                            let alert = UIAlertView(title: "unknown error", message: "an unknown error occured we have been notified and will be working on it as soon as possible", delegate: self, cancelButtonTitle: "OK")
                            alert.show()
                            
                            let newError = PFObject(className: "Error")
                            newError.setValue("\(error)", forKey: "errorName")
                            newError.save()
                        }
                        
                        
                    }else{
                        
                        self.isgood = true
                        self.next()
                        
                    }
                    
                    
                }
                
                
                
                
                
                
                
            }
            
        }else{
            
            if emailTextField.text! == "" {
                //error
                emailLabel.text = "Please enter a Username"
                emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if emailTextField.text!.characters.count < 6 {
                emailLabel.text = "must be a valid Username"
                emailLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if passwordTetxField.text! == "" {
                //error
                passwordLabel.text = "Please enter a Password"
                passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else if passwordTetxField.text?.characters.count < 8 {
                passwordLabel.text = "Invalid Password"
                passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                //shake screen
            }else{
                
                if isChecked == true {
                    NSUserDefaults.standardUserDefaults().setBool(true, forKey: "userIsSaved")
                    
                    NSUserDefaults.standardUserDefaults().setValue(emailTextField.text, forKey: "savedUsername")
                    NSUserDefaults.standardUserDefaults().setValue(passwordTetxField.text, forKey: "savedPassword")
                    
                }else{
                    //just do nothing
                    NSUserDefaults.standardUserDefaults().setBool(false, forKey: "userIsSaved")
                }
                
                PFUser.logInWithUsernameInBackground(emailTextField.text!, password: passwordTetxField.text!, block: { (user, error) -> Void in
                    
                    
                    if let error = error {
                        
                        if "\(error)" == "Error Domain=Parse Code=101 \"invalid login parameters\" UserInfo={code=101, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=invalid login parameters, NSLocalizedDescription=invalid login parameters}" {
                            
                            self.passwordLabel.text = "Invalid login credentials. please try again with a proper Username and Password."
                            self.passwordLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                            
                        }else{
                            
                            let alert = UIAlertView(title: "unknown error", message: "an unknown error occured we have been notified and will be working on it as soon as possible", delegate: self, cancelButtonTitle: "OK")
                            alert.show()
                            
                            let newError = PFObject(className: "Error")
                            newError.setValue("\(error)", forKey: "errorName")
                            newError.save()
                            
                            
                        }
                        
                    }else{
                        
                        self.performSegueWithIdentifier("secondtomain", sender: self)
                    }
                    
                })
                
            }
            
        }
        
        
    }
    
    func next() {
        
        let mylistgroup = PFObject(className: "Group")
        mylistgroup.setObject(self.userName1, forKey: "creator")
        mylistgroup.setObject("My List", forKey: "groupName")
        mylistgroup.setObject(PFUser.currentUser()!.objectId!, forKey: "objectId2")
        mylistgroup.setObject(true, forKey: "editable")
        mylistgroup.setObject("", forKey: "groupDescription")
        let bob : [String] = []
        mylistgroup.setObject(bob, forKey: "members")
        mylistgroup.setObject(1, forKey: "value")
        
        let file = PFFile(name: "uploadedImage.png", data: UIImageJPEGRepresentation(imageWithImage(image1, scaledToSize: CGSize(width: 75, height: 75)), 20)!)
        mylistgroup.setValue(file, forKey: "groupImage")
        
        mylistgroup.save()
        
        
        NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isNotFirstTime")
        self.performSegueWithIdentifier("secondtomain", sender: self)
        
    }
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        emailTextField.resignFirstResponder()
        passwordTetxField.resignFirstResponder()
        return true
        
    }
    
    
    func textFieldDidEndEditing(textField: UITextField) {
        passwordLabel.textColor = UIColor(colorLiteralRed: 21/255, green: 141/255, blue: 11/255, alpha: 1)
        emailLabel.textColor = UIColor(colorLiteralRed: 21/255, green: 141/255, blue: 11/255, alpha: 1)
    
        
    
    
    }
    
    
    func isGoodEmail(email: String) -> Bool
    {
        var hasAtribution = false
        var hasPeriod = false
        
        
        
        if email.rangeOfString("@") != nil {
            hasAtribution = true
        }
        
        if email.rangeOfString(".") != nil {
            hasPeriod = true
            
        }
        
        if hasAtribution == true && hasPeriod == true {
            
            return true
            
        }else{
            
            return false
            
        }
        
    }
    
    
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    
    
    

}
