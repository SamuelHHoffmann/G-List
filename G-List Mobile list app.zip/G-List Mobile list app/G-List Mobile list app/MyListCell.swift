//
//  MyListCell.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/29/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit

class MyListCell: UITableViewCell {

    @IBOutlet weak var itemDescription: UILabel!
    @IBOutlet weak var itemName: UILabel!
    
    @IBOutlet weak var userImageView: UIImageView!
    
    @IBOutlet weak var checkImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        userImageView.layer.cornerRadius = 58/2
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
