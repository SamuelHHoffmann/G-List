//
//  GroupListCell.swift
//  G-List Mobile list app
//
//  Created by Samuel Hoffmann on 12/22/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit

class GroupListCell: UITableViewCell {

    
    @IBOutlet weak var groupListImage: UIImageView!
    
    @IBOutlet weak var groupListName: UILabel!
    
    @IBOutlet weak var groupListMemberCount: UILabel!
    
    @IBOutlet weak var groupListDescription: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        groupListImage.layer.cornerRadius = 58/2
    }
    
}
