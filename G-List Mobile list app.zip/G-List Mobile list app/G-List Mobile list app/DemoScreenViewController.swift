//
//  DemoScreenViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/19/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit

class DemoScreenViewController: UIViewController {

    
    @IBOutlet weak var demoImageView: UIImageView!
    
    
    
    @IBOutlet weak var mainLabel: UILabel!
    
    var text1 = "first you want to sign up; follow the basic instructions and create for yourself a user. tap to continue"
    var text2 = "On the main there are a number of features: you have your basic settings, an about screen behind the small logo, the ability to add items to your personal list, the ability to create a group where others can add to your list, and lastly the ability to manage already created groups. "
    var text3 = "The new Note button allows you to add a note to yourself; notes usually consist of, but are not limited to, things, personal items to add to your own to-get list. "
    var text4 = "The new group button is what it says: you create a new group of people who can edit a list. The choice of who can get what and who can edit things is up to you the creator. "
    var text5 = "Lastly, tying the whole app together is the My List button, also found on the load screen for quick convince. The My List button allows you to see all the items for you to get, whether they are from your personal notes, or assigned to you in a group, they are the items for you to check off as you get them."
    var text6 = "tap to exit and know this demo can always be replayed in the settings screen --also, please enjoy G-List!                           G-List, revolutionizing the world by changing the way you stay organized."
    
    
    var image1 = UIImage(named: "1") //demo image
    
    var image2 = UIImage(named: "2") //demo image
    
    var image3 = UIImage(named: "3") //demo image
    
    var image4 = UIImage(named: "4") //demo image
    
    var image5 = UIImage(named: "5") //demo image
    
    var image6 = UIImage(named: "6") //just the g-list logo
    
    var boolx = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        demoImageView.image = image1
        mainLabel.text = text1
        
        mainLabel.alpha = 1
        
        
        let tapped = UITapGestureRecognizer(target: self, action: "tapped")
        
        demoImageView.addGestureRecognizer(tapped)
        mainLabel.addGestureRecognizer(tapped)
        
        
        
    }
    
    func tapped(){
        
        // if first time go back to login screen
        // else go back to setings screen
        // performSegueWithIdentifier("", sender: self)
        
        if demoImageView.image == image1 {
            
                demoImageView.image = image2
            mainLabel.text = text2
            
        }else if demoImageView.image == image2 {
          
                demoImageView.image = image3
            mainLabel.text = text3
            
        }else if demoImageView.image == image3 {
            
                demoImageView.image = image4
            mainLabel.text = text4
            
        }else if demoImageView.image == image4 {
            
                demoImageView.image = image5
            mainLabel.text = text5
            
        }else if demoImageView.image == image5 {
            
                demoImageView.image = image6
            mainLabel.text = text6
            
        }else{
            if boolx == false { //load screen
                performSegueWithIdentifier("demotowelcome", sender: self)
            }else{ //to settigns screen
                performSegueWithIdentifier("demotosettings", sender: self)
            }
        }
        
    }
    
    
    
    


}
