//
//  WelcomeViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/25/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse


class WelcomeViewController: UIViewController {

    
    @IBOutlet weak var constraintthingy: NSLayoutConstraint!
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var myListButton: UIButton!
 
    @IBOutlet weak var centerLabel: UILabel!
    
    @IBOutlet weak var thegraficslabel: UILabel!
    
    @IBOutlet weak var blockerView: UIView!
    
    override func viewDidLoad() {
        makeGradient()
        
        // uncomment this line once to reset if first time
        // NSUserDefaults.standardUserDefaults().setBool(false, forKey: "isNotFirstTime")
        // NSUserDefaults.standardUserDefaults().setBool(false, forKey: "firsttodemo")
        NSUserDefaults.standardUserDefaults().setDouble(2.5, forKey: "NewVersion")
        
        if view.bounds.width == 320 && view.bounds.height == 480 { //4s
            constraintthingy.constant = 300
            
        }else{
            constraintthingy.constant = 340
        }
        
        thegraficslabel.alpha = 0
        blockerView.alpha = 0
        
        
        let tappeded = UITapGestureRecognizer(target: self, action: "tapped22")
        
        thegraficslabel.addGestureRecognizer(tappeded)
        blockerView.addGestureRecognizer(tappeded)
        
        myListButton.enabled = false
        loginButton.setTitle("Sign Up", forState: UIControlState.Normal)
        
        NSUserDefaults.standardUserDefaults().synchronize()
        
        if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == true {
         
            if NSUserDefaults.standardUserDefaults().boolForKey("userIsSaved") == true {
                myListButton.enabled = true
            }
            
            loginButton.setTitle("Log In", forState: UIControlState.Normal)
        
        }
        
    }
    
    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.drawInRect(CGRectMake(0, 0, newSize.width, newSize.height))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func tapped22(){
        
        thegraficslabel.alpha = 0
        blockerView.alpha = 0
        
    }
    
    
    
    
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    @IBAction func loginButtonTapped(sender: AnyObject) {
        
        if NSUserDefaults.standardUserDefaults().boolForKey("firsttodemo") == true {
            
            if NSUserDefaults.standardUserDefaults().boolForKey("isNotFirstTime") == false {
                
                // move this line till after the second info screen NSUserDefaults.standardUserDefaults().setBool(true, forKey: "isNotFirstTime")
                performSegueWithIdentifier("loadtofirst", sender: self)
                
            }else{
                
                if NSUserDefaults.standardUserDefaults().boolForKey("userIsSaved") == true {
                    
                    PFUser.logInWithUsernameInBackground(NSUserDefaults.standardUserDefaults().stringForKey("savedUsername")!, password: NSUserDefaults.standardUserDefaults().stringForKey("savedPassword")!, block: { (user, error) -> Void in
                        
                        
                        if let error = error {
                            
                            if "\(error)" == "Error Domain=Parse Code=101 \"invalid login parameters\" UserInfo={code=101, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=invalid login parameters, NSLocalizedDescription=invalid login parameters}" {
                                
                                self.performSegueWithIdentifier("loadtosecond", sender: self)
                                
                            }else{
                                
                                
                                let alert = UIAlertView(title: "error", message: "\(error)", delegate: self, cancelButtonTitle: "OK")
                                alert.show()
                                
                                print("\(error)")
                                
                            }
                        }else{
                            
                            if NSUserDefaults.standardUserDefaults().doubleForKey("NewVersion") != NSUserDefaults.standardUserDefaults().doubleForKey("currentVersion") {
                                
                                NSUserDefaults.standardUserDefaults().setDouble(NSUserDefaults.standardUserDefaults().doubleForKey("NewVersion"), forKey: "currentVersion")
                                
                                NSUserDefaults.standardUserDefaults().setBool(false, forKey: "Version Optimized")
                                
                            }
                            
                            if NSUserDefaults.standardUserDefaults().boolForKey("Version Optimized") != true {
                                
                                let query96 = PFQuery(className: "_User")
                                
                                query96.whereKey("objectId", equalTo: PFUser.currentUser()!.objectId!)
                                
                                query96.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                                    if error == nil && objects != nil{
                                        let obj = (objects as! [PFObject]).first!
                                        
                                        let pic = self.imageWithImage(UIImage(named: "images")!, scaledToSize: CGSize(width: 75, height: 75))
                                        
                                        let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(pic)!)
                                        
                                        obj.setValue(file, forKey: "UserImage")
                                        
                                        obj.save()
                                        
                                        NSUserDefaults.standardUserDefaults().setBool(true, forKey: "Version Optimized")
                                        
                                    }
                                }
                                
                                let query2 = PFQuery(className: "Group")
                                
                                let number = query2.countObjects()
                                
                                query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                                    if error == nil && objects != nil{
                                        var counter = 0
                                        for index in objects!{
                                            //(index as! PFObject).pin()      //pining saves the object in offline parse db
                                            //the offline parse db is created automatically
                                            counter = counter + 1
                                            
                                            let joe = index as! PFObject  //this makes the local food object
                                            
                                            
                                            let arr = index.objectForKey("members") as! [String]
                                            
                                            if arr.contains(PFUser.currentUser()!.username!) {
                                                
                                                let pic = self.imageWithImage(UIImage(named: "images")!, scaledToSize: CGSize(width: 75, height: 75))
                                                
                                                let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(pic)!)
                                                
                                                joe.setValue(file, forKey: "groupImage")
                                                
                                                joe.save()
                                            }
                                            
                                            if counter == number {
                                                
                                                self.performSegueWithIdentifier("welcometomain", sender: self)
                                                
                                            }
                                            
                                            
                                        }
                                    }
                                    
                                    
                                }
                                
                                
                            }else{
                                self.performSegueWithIdentifier("welcometomain", sender: self)
                            }
                            
                            
                            
                        }
                        
                    })
                    
                }else{
                    performSegueWithIdentifier("loadtosecond", sender: self)
                }
            }
            
        }else{
            
            NSUserDefaults.standardUserDefaults().setBool(true, forKey: "firsttodemo")
            performSegueWithIdentifier("welcometodemo", sender: self)
            
        }
        
        
        
    }
    
    
    @IBAction func myListButtonTapped(sender: AnyObject) {
        
        PFUser.logInWithUsernameInBackground(NSUserDefaults.standardUserDefaults().stringForKey("savedUsername")!, password: NSUserDefaults.standardUserDefaults().stringForKey("savedPassword")!, block: { (user, error) -> Void in
            
            
            if let error2 = error {
                
                if "\(error2)" == "Error Domain=Parse Code=101 \"invalid login parameters\" UserInfo={code=101, originalError=Error Domain=NSURLErrorDomain Code=-1011 \"(null)\", temporary=0, error=invalid login parameters, NSLocalizedDescription=invalid login parameters}" {
                    
                    self.centerLabel.text = "We are sorry for the inconvience, it seems that the user didn't properly save. Please log In with the log In button, and then follow to My List."
                    self.centerLabel.textColor = UIColor(colorLiteralRed: 255/255, green: 0/255, blue: 0/255, alpha: 1)
                    
                }else{
                
                
                let alert = UIAlertView(title: "error", message: "\(error2)", delegate: self, cancelButtonTitle: "OK")
                alert.show()
                
                print("\(error)")
                    
                }
                
            }else{
                
                
                if NSUserDefaults.standardUserDefaults().doubleForKey("NewVersion") != NSUserDefaults.standardUserDefaults().doubleForKey("currentVersion") {
                    
                    NSUserDefaults.standardUserDefaults().setDouble(NSUserDefaults.standardUserDefaults().doubleForKey("NewVersion"), forKey: "currentVersion")
                    
                    NSUserDefaults.standardUserDefaults().setBool(false, forKey: "Version Optimized")
                    
                }
                
                if NSUserDefaults.standardUserDefaults().boolForKey("Version Optimized") != true {
                    
                    let query96 = PFQuery(className: "_User")
                    
                    query96.whereKey("objectId", equalTo: PFUser.currentUser()!.objectId!)
                    
                    query96.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                        if error == nil && objects != nil{
                            let obj = (objects as! [PFObject]).first!
                            
                            let pic = self.imageWithImage(UIImage(named: "images")!, scaledToSize: CGSize(width: 75, height: 75))
                            
                            let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(pic)!)
                            
                            obj.setValue(file, forKey: "UserImage")
                            
                            obj.save()
                            
                            NSUserDefaults.standardUserDefaults().setBool(true, forKey: "Version Optimized")
                            
                            
                        }
                    }
                    
                    let query2 = PFQuery(className: "Group")
                    
                    let number = query2.countObjects()
                    
                    query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                        if error == nil && objects != nil{
                            var counter = 0
                            for index in objects!{
                                //(index as! PFObject).pin()      //pining saves the object in offline parse db
                                //the offline parse db is created automatically
                                counter = counter + 1
                                
                                let joe = index as! PFObject  //this makes the local food object
                                
                                
                                let arr = index.objectForKey("members") as! [String]
                                
                                if arr.contains(PFUser.currentUser()!.username!) {
                                    
                                    let pic = self.imageWithImage(UIImage(named: "images")!, scaledToSize: CGSize(width: 75, height: 75))
                                    
                                    let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(pic)!)
                                    
                                    joe.setValue(file, forKey: "groupImage")
                                    
                                    joe.save()
                                }
                                
                                if counter == number {
                                    
                                    self.performSegueWithIdentifier("loadtomylist", sender: self)
                                    
                                }
                                
                                
                            }
                        }
                        
                        
                    }
                    
                    
                }else{
                    self.performSegueWithIdentifier("loadtomylist", sender: self)
                }
                
                
            }
            
        })
        
        
        
    }
    
}
