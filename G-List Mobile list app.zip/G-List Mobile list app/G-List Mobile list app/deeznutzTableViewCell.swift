//
//  deeznutzTableViewCell.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/13/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit

class deeznutzTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var SENDER: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var itemDescription: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
