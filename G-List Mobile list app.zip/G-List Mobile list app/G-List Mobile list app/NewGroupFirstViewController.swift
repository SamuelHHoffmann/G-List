//
//  NewGroupFirstViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 1/15/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit


class NewGroupFirstViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var groupImage: UIImageView!
    
    @IBOutlet weak var groupNameTextField: UITextField!
    
    var name = ""
    
    var image1 = UIImage(named: "images")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeGradient()
        
        
        if name == "(Group Name)" {
            name = ""
        }
        groupNameTextField.text! = name
        
        groupImage.image = image1
        
        groupNameTextField.delegate = self
        
        let imagedTappedGestureRecognizer = UITapGestureRecognizer(target: self, action: "imagetapped")
        
        groupImage.addGestureRecognizer(imagedTappedGestureRecognizer)
        
        groupImage.layer.cornerRadius = 245/2
        groupImage.clipsToBounds = true
        
        
        // Do any additional setup after loading the view.
    }
    
    func imagetapped(){
        //if camera is available then select the image
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            let cameraViewC = UIImagePickerController()
            
            cameraViewC.sourceType = UIImagePickerControllerSourceType.Camera
            cameraViewC.delegate = self
            
            self.presentViewController(cameraViewC, animated: true, completion: nil)
            
            
        }
    }
    
    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.drawInRect(CGRectMake(0, 0, newSize.width, newSize.height))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func imagePickerController(picker: UIImagePickerController, var didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        
        image = imageWithImage(image, scaledToSize: CGSize(width: 75, height: 75))
        groupImage.image = image
        image1 = image
        picker.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    
    @IBAction func continueButtonTapped(sender: AnyObject) {
        
        
        
        performSegueWithIdentifier("newgroupfirsttosecond", sender: self)
        
    }
    

    @IBAction func backButtonTapped(sender: AnyObject) {
        
       performSegueWithIdentifier("newgrouponetomain", sender: self)
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "newgroupfirsttosecond" {
            
            let nextViewController = segue.destinationViewController as! NewGroupSecondViewController
            
            nextViewController.passedImage = image1!
            
            
            if name == "" {
                nextViewController.passedName = "(Group Name)"
            }else{
                nextViewController.passedName = name
            }
        }
        
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        name = groupNameTextField.text!
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        groupNameTextField.resignFirstResponder()
        return true
    }
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    
}
