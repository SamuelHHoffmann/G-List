//
//  UserInfoViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 2/29/16.
//  Copyright © 2016 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class UserInfoViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    @IBOutlet weak var backbutton: UIButton!
    
    
    @IBOutlet weak var userImageView: UIImageView!
    
    
    @IBOutlet weak var usernametextField: UITextField!
    
    
    @IBOutlet weak var emailtextField: UITextField!
    
    
    @IBOutlet weak var passwordtextField: UITextField!
    
    
    @IBOutlet weak var showpasswordbutton: UIButton!
    
    
    var hasChanged = false
    
    var username = PFUser.currentUser()!.username!
    
    var profilePic = UIImage()
    
    var email = PFUser.currentUser()!.email!
    
    var password = PFUser.currentUser()!.password
    
    var passwordShown = false
    
    var oldUserNAme = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        let tappedges = UITapGestureRecognizer(target: self, action: "tapped")
        
        userImageView.addGestureRecognizer(tappedges)
        
        
        oldUserNAme = PFUser.currentUser()!.username!
        
        let query = PFQuery(className: "_User")
        
        query.whereKey("objectId", equalTo: (PFUser.currentUser()?.objectId)!)
        
        print(query.countObjects())
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                let obj = (objects as! [PFObject]).first!
                
                let file = obj.valueForKey("UserImage") as! PFFile
                
                let data = file.getData()
                
                self.profilePic = UIImage(data: data!)!
                
                self.userImageView.image = self.profilePic
                
                self.setInfo()
            }
        }
        
        usernametextField.delegate = self
        emailtextField.delegate = self
        passwordtextField.delegate = self
        
        
        userImageView.image = profilePic
        usernametextField.text = username
        emailtextField.text = email
        passwordtextField.text = password
        
        setInfo()
    }
    
    
    func tapped() {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera){
            let cameraViewC = UIImagePickerController()
            cameraViewC.sourceType = UIImagePickerControllerSourceType.Camera
            cameraViewC.delegate = self
            
            self.presentViewController(cameraViewC, animated: true, completion: nil)
            
            
        }
        
    }
    
    
    func imagePickerController(picker: UIImagePickerController, var didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
        
        hasChanged = true
        
        image = self.imageWithImage(image, scaledToSize: CGSize(width: 75, height: 75))
        userImageView.image = image
        setInfo()
        picker.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func setInfo() {
        
        profilePic = userImageView.image!
        username = usernametextField.text!
        email = emailtextField.text!
        password = passwordtextField.text!
        
        usernametextField.text = username
        emailtextField.text = email
        passwordtextField.text = password
        userImageView.image = profilePic
        
        if hasChanged == true {
            backbutton.setTitle("Save", forState: UIControlState.Normal)
        }else{
            backbutton.setTitle("Back", forState: UIControlState.Normal)
        }
        
        if passwordShown == false {
            passwordtextField.secureTextEntry = true
        }else{
            passwordtextField.secureTextEntry = false
        }
    }
    
    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.drawInRect(CGRectMake(0, 0, newSize.width, newSize.height))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage
    }
    
    
    
    @IBAction func backbuttonTapped(sender: AnyObject) {
        
        if hasChanged == true {
            //save file
            
            
            
            let query = PFQuery(className: "_User")
            
            query.whereKey("objectId", equalTo: (PFUser.currentUser()?.objectId)!)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.setValue(self.username, forKey: "username")
                    obj.setValue(self.email, forKey: "email")
                    
                    self.profilePic = self.imageWithImage(self.profilePic, scaledToSize: CGSize(width: 75, height: 75))
                    
                    let file = PFFile(name: "uploadedImage.png", data: UIImagePNGRepresentation(self.profilePic)!)
                    
                    obj.setValue(file, forKey: "UserImage")
                    
                    if self.password != "" {
                        
                        obj.setValue(self.password, forKey: "password")
                        if NSUserDefaults.standardUserDefaults().boolForKey("userIsSaved") == true {
                            
                            NSUserDefaults.standardUserDefaults().setValue(self.password, forKey: "savedPassword")
                            
                        }
                    }
                    
                    
                    if NSUserDefaults.standardUserDefaults().boolForKey("userIsSaved") == true {
                        
                        NSUserDefaults.standardUserDefaults().setValue(self.username, forKey: "savedUsername")
                        
                    }
                    
                    obj.saveInBackground()
                    print(1)
                }
            }
            
            

            
            let query3 = PFQuery(className: "Group")
            
            query3.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    for index in objects!{
                        
                        
                        var tempmeme = (index as! PFObject).objectForKey("members") as! [String]
                        
                        if tempmeme.contains(self.oldUserNAme) {
                            
                            tempmeme[tempmeme.indexOf(self.oldUserNAme)!] = self.username
                            (index as! PFObject).setValue(tempmeme, forKey: "members")
                            (index as! PFObject).saveInBackground()
                        }
                    }
                    
                }
            }
            
            let query2 = PFQuery(className: "Group")
            
            query2.whereKey("objectId2", equalTo: (PFUser.currentUser()?.objectId)!)
            
            query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.setValue(self.username, forKey: "creator")
                    
                    obj.saveInBackground()
                    self.performSegueWithIdentifier("infotoabout", sender: self)
                }
            }
            
            
        }else{
            performSegueWithIdentifier("infotoabout", sender: self)
        }
        
    
        
    }
    
    
   
    @IBAction func showpasswordButtonTapped(sender: AnyObject) {
        
        if passwordShown == false {
            passwordShown = true
        }else{
            passwordShown = false
        }
        
        setInfo()
        
    }
    
    var sure = false
    
    @IBAction func deleteUserButtonTapped(sender: AnyObject) {
        
        if sure == true {
        
        let query = PFQuery(className: "_User")
        
        query.whereKey("objectId", equalTo: (PFUser.currentUser()?.objectId)!)
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                let obj = (objects as! [PFObject]).first!
                
                obj.delete()
                
                NSUserDefaults.standardUserDefaults().setValue(false, forKey: "isNotFirstTime")
                NSUserDefaults.standardUserDefaults().setValue(false, forKey: "userIsSaved")
                NSUserDefaults.standardUserDefaults().setValue("", forKey: "savedPassword")
                NSUserDefaults.standardUserDefaults().setValue("", forKey: "savedUsername")
                self.performSegueWithIdentifier("infotowelcome", sender: self)
            }
        }
            
        }else{
            
            
            let alert = UIAlertView(title: "Deleting User", message: "Are you sure you want to delete your user? if so press delete again.", delegate: self, cancelButtonTitle: "OK")
            alert.show()
            
            sure = true
        }
        
    }
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    var tempUsername = String()
    
    var tempImage = UIImage()
    
    var tempemail = String()
    
    var tempPassword = String()
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        tempUsername = username
        tempImage = profilePic
        tempemail = email
        tempPassword = password!
        
        
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        setInfo()
        
        if tempUsername != username || tempImage != profilePic || tempemail != email || tempPassword != password! {
            
            hasChanged = true
            setInfo()
        }
        
        
        
    }
    
    
    
    
    
    
    
    func makeInverseGradient(){
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    

}
