//
//  GroupViewController.swift
//  G-List
//
//  Created by Samuel Hoffmann on 12/30/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Foundation
import Parse

class GroupViewController: UIViewController, UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate, UITextViewDelegate {

    @IBOutlet weak var groupName: UIButton!
    
    @IBOutlet weak var mainTableView: UITableView!
    
    @IBOutlet weak var littleTabThing: UIImageView!
    
    @IBOutlet weak var itemName: UITextField!
    @IBOutlet weak var addbutton: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var quntitiyLabel: UILabel!
    @IBOutlet weak var quantityTextField: UITextField!
    @IBOutlet weak var add2: UIButton!
    @IBOutlet weak var quantityBackbutt: UIButton!
    @IBOutlet weak var quantityPlus: UIButton!
    @IBOutlet weak var quantityMinus: UIButton!
    
    
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var groupimageview: UIImageView!
    
    var selectedGroup : Group = Group()
    
    var mainArray : [Item] = []
    
    var reverseArray : [Item] = []
    
    var refreshControl:UIRefreshControl!
    
    var quantity = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        makeInverseGradient()
        
        itemName.alpha = 1
        addbutton.alpha = 1
        nameLabel.alpha = 1
        descriptionLabel.alpha = 1
        descriptionTextView.alpha = 1
        
        quntitiyLabel.alpha = 0
        quantityTextField.alpha = 0
        add2.alpha = 0
        quantityBackbutt.alpha = 0
        quantityPlus.alpha = 0
        quantityMinus.alpha = 0
        
        
        
        littleTabThing.layer.cornerRadius = 25
        
        itemName.delegate = self
        mainTableView.delegate = self
        mainTableView.dataSource = self
        descriptionTextView.delegate = self
        
        groupName.setTitle(selectedGroup.groupName, forState: UIControlState.Normal)
        
        groupimageview.image = selectedGroup.groupImage
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
        self.mainTableView.addSubview(refreshControl)
        
        refreshGroup()
    }
    
    
    func refresh(sender:AnyObject){
        
        refreshGroup()
        refreshControl.endRefreshing()
    }
    
    
    
    func refreshGroup(){
        
        let query = PFQuery(className: "Group")
        
        query.whereKey("objectId", equalTo: selectedGroup.objectId)
        
        //query.fromLocalDatastore()    //uncomment to query from the offline store
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                for index in objects!{
                    //(index as! PFObject).pin()      //pining saves the object in offline parse db
                    //the offline parse db is created automatically
                    print(1)
                    self.makeGroups(index as! PFObject)
                    
                }
            }
            
        }
        
    }
    
    
    var arr : [Item] = []
    
    func makeArray(index:PFObject){
        print(4)
        let item = Item()
        item.objectId = index.valueForKey("objectId") as! String
        item.name = index.valueForKey("name") as! String
        item.descrpiton = index.valueForKey("descrpiton") as! String
        item.group = index.valueForKey("group") as! String
        item.gotten = index.valueForKey("gotten") as! Bool
        item.rejected = index.valueForKey("rejected") as! Bool
        item.sender = index.valueForKey("sender") as! String
        item.quantity = index.valueForKey("quantity") as! Int
        
        arr.append(item)
        
    }
    
    
    
    func makeGroups(index:PFObject){
        print(2)
        arr = []
        
        let selectedGroup = Group()
        
        selectedGroup.objectId = index.valueForKey("objectId") as! String
        selectedGroup.creator = index.valueForKey("creator") as! String
        selectedGroup.editable = index.valueForKey("editable") as! Bool
        selectedGroup.groupDescription = index.valueForKey("groupDescription") as! String
        //self.selectedGroup.groupImage = index("groupImage") as! UIImage
        
        
        
        let query2 = PFQuery(className: "Item")
        
        query2.whereKey("group", equalTo: selectedGroup.objectId)
        
        query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                for index in objects!{
                    //(index as! PFObject).pin()      //pining saves the object in offline parse db
                    //the offline parse db is created automatically
                    print(3)
                    self.makeArray(index as! PFObject)
                    
                }
            }
            //print("2")
            //print(self.arr.count)
            
            selectedGroup.itemList = self.arr
            
            selectedGroup.groupName = index.valueForKey("groupName") as! String
            selectedGroup.members = index.valueForKey("members") as! [String]
            print(5)
            self.mainArray = selectedGroup.itemList
            
            self.reverseArray = self.mainArray//.reverse()
            
            print(6)
            self.mainTableView.reloadData()
    }
    
    
    
        
        
    }
    
    
    
    
    
    func textViewDidChange(textView: UITextView) {
        
        if textView.text.containsString("\n") {
            
            bottomConstraint.constant = -140
            descriptionTextView.resignFirstResponder()
            
        }
        
        
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        bottomConstraint.constant = 225
        
        if descriptionTextView.text == "Please enter the item information" {
            descriptionTextView.text = ""
        }
        
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        bottomConstraint.constant = 0
    }
    
    
    
    
    
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        mainTableView.deselectRowAtIndexPath(indexPath, animated: false)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        
        if reverseArray.count == 0 {
            
            //add the other image
        }
        
        return reverseArray.count
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        
        let cell = mainTableView.dequeueReusableCellWithIdentifier("deeznutz") as! deeznutzTableViewCell
        
        cell.name.text = "\(reverseArray[indexPath.row].quantity) (of) \(reverseArray[indexPath.row].name)"
        cell.SENDER.text = reverseArray[indexPath.row].sender
        cell.itemDescription.text = reverseArray[indexPath.row].descrpiton
        
        return cell
    }
    
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        bottomConstraint.constant = 0
        itemName.resignFirstResponder()
        
        
        return true
    }
    
    
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
         bottomConstraint.constant = 225
        
    }
    
    
    @IBAction func handlePan(recognizer:UIPanGestureRecognizer) {
        
        let translation = recognizer.translationInView(self.view)
        
        itemName.resignFirstResponder()
        
        if bottomConstraint.constant >= -140.0 && bottomConstraint.constant <= 0.0{
            
           
            if translation.y <= 0 {
                
                
                bottomConstraint.constant -= translation.y
                updateViewConstraints()
            }
            
            if translation.y >= 0 {
                
                
                bottomConstraint.constant -= translation.y
                updateViewConstraints()
                
                
            }
            recognizer.setTranslation(CGPointZero, inView: self.view)
        }
        
        if bottomConstraint.constant < -140{
            
           bottomConstraint.constant = -140
            
        }else if bottomConstraint.constant > 0{
            
            bottomConstraint.constant = 0
            
        }
        
        
    }
    
    var newItem = PFObject(className: "Item")
    
    @IBAction func sendButtonTapped(sender: AnyObject) {
        
        if itemName.text != "" {
            //make the new item
//            let newItem = PFObject(className: "Item")
//            newItem.sender = PFUser.currentUser()!.username!
//            newItem.name = itemName.text!
//            newItem.gotten = false
//            newItem.rejected = false
//            newItem.descrpiton = descriptionTextView.text
//            newItem.group = selectedGroup.objectId
            
            newItem = PFObject(className: "Item")
            newItem.setObject(itemName.text!, forKey: "name")
            newItem.setObject(descriptionTextView.text, forKey: "descrpiton")
            newItem.setObject(false, forKey: "gotten")
            newItem.setObject(false, forKey: "rejected")
            newItem.setObject(PFUser.currentUser()!.username!, forKey: "sender")
            newItem.setObject(selectedGroup.objectId, forKey: "group")
            newItem.ACL?.setPublicReadAccess(true)
            newItem.ACL?.setPublicWriteAccess(true)
            
            
            //add item to the array at normal direction
            
            
            itemName.alpha = 0
            addbutton.alpha = 0
            nameLabel.alpha = 0
            descriptionLabel.alpha = 0
            descriptionTextView.alpha = 0
            
            quntitiyLabel.alpha = 1
            quantityTextField.alpha = 1
            add2.alpha = 1
            quantityBackbutt.alpha = 1
            quantityPlus.alpha = 1
            quantityMinus.alpha = 1
            
            quantity = 1
            quantityTextField.text = "\(quantity)"
            quntitiyLabel.text = "How many \(itemName.text!) do you need?"
            
            descriptionTextView.resignFirstResponder()
            itemName.resignFirstResponder()
            
            
        }
    
    }
    
    
    
    @IBAction func AddTwoTapped(sender: AnyObject) {
        
        newItem.setObject(quantity, forKey: "quantity")
        
        newItem.save()
        
        
        descriptionTextView.resignFirstResponder()
        itemName.resignFirstResponder()
        
        bottomConstraint.constant = -140
        
        //refresh the table views
        
        itemName.alpha = 1
        addbutton.alpha = 1
        nameLabel.alpha = 1
        descriptionLabel.alpha = 1
        descriptionTextView.alpha = 1
        
        quntitiyLabel.alpha = 0
        quantityTextField.alpha = 0
        add2.alpha = 0
        quantityBackbutt.alpha = 0
        quantityPlus.alpha = 0
        quantityMinus.alpha = 0
        
        descriptionTextView.text = ""
        itemName.text = ""
        
        refreshGroup()
        
    }
    
    
    @IBAction func back2Tapped(sender: AnyObject) {
        
        itemName.alpha = 1
        addbutton.alpha = 1
        nameLabel.alpha = 1
        descriptionLabel.alpha = 1
        descriptionTextView.alpha = 1
        
        quntitiyLabel.alpha = 0
        quantityTextField.alpha = 0
        add2.alpha = 0
        quantityBackbutt.alpha = 0
        quantityPlus.alpha = 0
        quantityMinus.alpha = 0
        
    }
    
   
    @IBAction func addQuantityTapped(sender: AnyObject) {
        
        if quantity == 99 {
            
        }else{
            quantity++
        }
        quantityTextField.text = "\(quantity)"
        
    }
    
    @IBAction func minusQuantityTapped(sender: AnyObject) {
    
        if quantity == 1 {
            
        }else{
            quantity--
        }
        quantityTextField.text = "\(quantity)"
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        performSegueWithIdentifier("grouptomain", sender: self)
    }
    
    
    
    @IBAction func groupNameTapped(sender: AnyObject) {
        
        //go to settigns of the group
        
        performSegueWithIdentifier("grouptogroupsettings", sender: self)
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "grouptogroupsettings" {
            
            let nextViewController = segue.destinationViewController as! GroupSettingsViewController
            
            nextViewController.passedGroup = selectedGroup
        }else if segue.identifier == "grouptomain" {
            
            if PFUser.currentUser()!.username == selectedGroup.creator {
                
                let query = PFQuery(className: "Group")
                
                query.whereKey("objectId", equalTo: selectedGroup.objectId)
                
                //query.fromLocalDatastore()    //uncomment to query from the offline store
                
                query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                    if error == nil && objects != nil{
                        let obj = (objects as! [PFObject]).first!
                        //(index as! PFObject).pin()      //pining saves the object in offline parse db
                        //the offline parse db is created automatically
                        
                        obj.setValue(self.selectedGroup.groupName, forKey: "groupName")
                        obj.setValue(self.selectedGroup.groupDescription, forKey: "groupDescription")
                        obj.setValue(self.selectedGroup.members, forKey: "members")
                        
                        let file = PFFile(name: "uploadedImage\(Int(arc4random_uniform(2000) + 0)).png", data: UIImagePNGRepresentation(self.selectedGroup.groupImage)!)
                        
                        obj.setValue(file, forKey: "groupImage")
                        
                        obj.saveInBackground()
                        
                    }
                    
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func doAction(tableView: UITableView, indexPath: NSIndexPath, type: String) {
        
        if type == "edit" {
            
            //set the data feilds to the info and save the number to over write it
            itemName.text = reverseArray[indexPath.row].name
            descriptionTextView.text = reverseArray[indexPath.row].descrpiton
            
            let query = PFQuery(className: "Item")
            
            query.whereKey("objectId", equalTo:  reverseArray[indexPath.row].objectId)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.delete()
                    self.reverseArray.removeAtIndex(indexPath.row)
                    self.itemName.becomeFirstResponder()
                    self.mainTableView.reloadData()
                    
                }
            }
            
        }else if type == "delete" {
            
            
            let query = PFQuery(className: "Item")
            
            query.whereKey("objectId", equalTo:  reverseArray[indexPath.row].objectId)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.delete()
                    self.reverseArray.removeAtIndex(indexPath.row)
                    self.mainTableView.reloadData()
                }
            }
            
            
            
        }else if type == "reject" {
            
            
            let query = PFQuery(className: "Item")
            
            query.whereKey("objectId", equalTo:  reverseArray[indexPath.row].objectId)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.setValue(true, forKey: "rejected")
                    obj.save()
                    self.reverseArray[indexPath.row].rejected = true
                    self.mainTableView.reloadData()
                    
                }
            }
            
            //notify the the contributer of that item that it has been rejected (in app by group, and outside of app)
            
        }else if type == "rejected" {
            
            
        }
        
    }
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let edit = UITableViewRowAction(style: .Normal, title: "edit") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "edit")
        }
        edit.backgroundColor = UIColor(red: 225/255, green: 225/255, blue: 225/255, alpha: 0.50)
        
        let delete = UITableViewRowAction(style: .Normal, title: "delete") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "delete")
        }
        delete.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        let reject = UITableViewRowAction(style: .Normal, title: "reject") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "reject")
        }
        reject.backgroundColor = UIColor(red: 190/255, green: 190/255, blue: 190/255, alpha: 0.50)
        
        let rejected = UITableViewRowAction(style: .Normal, title: "rejected") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "rejected")
        }
        rejected.backgroundColor = UIColor(red: 110/255, green: 29/255, blue: 35/255, alpha: 0.50)
        
        let gotten = UITableViewRowAction(style: .Normal, title: "gotten") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "gotten")
        }
        gotten.backgroundColor = UIColor(red: 26/255, green: 113/255, blue: 4/255, alpha: 0.50)
        
        if selectedGroup.creator == PFUser.currentUser()!.username {
            
            if reverseArray[indexPath.row].rejected == true{
                return [edit, delete, rejected]
            }else{
                if reverseArray[indexPath.row].gotten == true {
                    return [delete, gotten]
                }else{
                    return [edit, delete, reject]
                    
                }
            }
            
            
            
        }else{
            
            if reverseArray[indexPath.row].sender == PFUser.currentUser()!.username {
                
                if reverseArray[indexPath.row].rejected == true{
                    return [edit, delete, rejected]
                }else{
                    if reverseArray[indexPath.row].gotten == true {
                        return [delete, gotten]
                    }else{
                        return [edit, delete]
                
                    }
                }
                
            }
            return []
        }
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    func makeInverseGradient(){
        
        let bottomColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let topColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }

}
