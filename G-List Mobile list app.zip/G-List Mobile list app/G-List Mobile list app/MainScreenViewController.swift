//
//  ViewController.swift
//  G-List Mobile list app
//
//  Created by Samuel Hoffmann on 12/21/15.
//  Copyright © 2015 Samuel Hoffmann. All rights reserved.
//

import UIKit
import Parse

class MainScreenViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate {

    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var groupListsTableView: UITableView!
    
    var groupList : [Group] = []

    var tempgroupList : [Group] = []
    
    var quantity = 0
    
    @IBOutlet weak var quantityLabel: UILabel!
    @IBOutlet weak var addbutton2: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var quantyityTextField: UITextField!
    @IBOutlet weak var addquantitybutton: UIButton!
    @IBOutlet weak var minusButton: UIButton!
    
    
    
    
    
    
    @IBOutlet weak var addButtonasLabel: UIButton!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var itemNameLabel: UILabel!
    @IBOutlet weak var itemName: UITextField!
    
    @IBOutlet weak var itemDescription: UITextView!
    
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    var refreshControl:UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //makeGradient()
        
        addButtonasLabel.alpha = 1
        descriptionLabel.alpha = 1
        itemNameLabel.alpha = 1
        itemName.alpha = 1
        itemDescription.alpha = 1
        
        quantityLabel.alpha = 0
        addbutton2.alpha = 0
        backButton.alpha = 0
        quantyityTextField.alpha = 0
        addquantitybutton.alpha = 0
        minusButton.alpha = 0
        
        
        groupListsTableView.delegate = self
        groupListsTableView.dataSource = self
    
        
        //set up about image
        let imageIconTapped = UITapGestureRecognizer(target: self, action: "iconTapped")
        iconImageView.addGestureRecognizer(imageIconTapped)
        
        //get list
        getGroupList()
        
        
        quantyityTextField.delegate = self
        itemName.delegate = self
        itemDescription.delegate = self
        itemDescription.layer.cornerRadius = 5
    
        bottomConstraint.constant = -140
        
        
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
        self.groupListsTableView.addSubview(refreshControl)
        
    }

    
    func refresh(sender:AnyObject)
    {
        
        getGroupList()
        refreshControl.endRefreshing()
    }
    
    
    
    
    
    
    func getGroupList() {
        
        groupList = []
        
        
        let query2 = PFQuery(className: "Group")
        
        query2.whereKey("editable", equalTo: true)
        
        print("found \(query2.countObjects()) objects")
        
        print(1)
        
        
        query2.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                var counter = 0
                for index in objects!{
                    //(index as! PFObject).pin()      //pining saves the object in offline parse db
                    //the offline parse db is created automatically
                    counter++
                    
                    print(2)
                    
                    self.makeGroupArray(index as! PFObject)  //this makes the local food object
                    
                    print(4)
                }
            }
            
            
        }
        
        
    }
   
    
    
    
    
    func makeGroupArray(index:PFObject){
        
        print(3)
        
        let newGroup = Group()
        newGroup.editable = index.objectForKey("editable") as! Bool
        newGroup.groupDescription = index.objectForKey("groupDescription") as! String
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        
        newGroup.groupName = index.objectForKey("groupName") as! String
        newGroup.members = index.objectForKey("members") as! [String]
        newGroup.creator = index.objectForKey("creator") as! String
        newGroup.objectId = index.objectId!
        
        
        if newGroup.members.contains("\(PFUser.currentUser()!.username!)") {
            
            let file = index.objectForKey("groupImage") as! PFFile
            
            let data = file.getData()
            
            newGroup.groupImage = UIImage(data: data!)!

            
        }else{
            
            newGroup.groupImage = UIImage(named: "images")!
        }
        
        
        
        
        
        
        
        /////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////
        
        
        if newGroup.members.contains("\(PFUser.currentUser()!.username!)") {
            
            print("!!")
            
            groupList.append(newGroup)
            groupListsTableView.reloadData()
            
        }
        //self.groupListsTableView.reloadData()
    }

    
    
    
    
    
    
    
    
    
    
    @IBAction func handlePan(recognizer:UIPanGestureRecognizer) {
        
        let translation = recognizer.translationInView(self.view)
        
        //itemName.resignFirstResponder()
        
        if bottomConstraint.constant >= -140.0 && bottomConstraint.constant <= 0.0{
            
            
            if translation.y <= 0 {
                
                
                bottomConstraint.constant -= translation.y
                updateViewConstraints()
            }
            
            if translation.y >= 0 {
                
                
                bottomConstraint.constant -= translation.y
                updateViewConstraints()
                
                
            }
            recognizer.setTranslation(CGPointZero, inView: self.view)
        }
        
        if bottomConstraint.constant < -140{
            
            bottomConstraint.constant = -140
            
        }else if bottomConstraint.constant > 0{
            
            bottomConstraint.constant = 0
            
        }
        
        
    }
    
    
    var newItem = PFObject(className: "Item")
    
    @IBAction func addButtonTapped(sender: AnyObject) {
        
        if itemName.text != "" {
           
            newItem = PFObject(className: "Item")
            newItem.setObject(itemName.text!, forKey: "name")
            newItem.setObject(itemDescription.text, forKey: "descrpiton")
            newItem.setObject(false, forKey: "gotten")
            newItem.setObject(false, forKey: "rejected")
            newItem.setObject(PFUser.currentUser()!.username!, forKey: "sender")
            
            quantity = 1
            
            addButtonasLabel.alpha = 0
            descriptionLabel.alpha = 0
            itemNameLabel.alpha = 0
            itemName.alpha = 0
            itemDescription.alpha = 0
            
            quantityLabel.text = "How many \(itemName.text!) do you need?"
            
            quantityLabel.alpha = 1
            addbutton2.alpha = 1
            backButton.alpha = 1
            quantyityTextField.alpha = 1
            addquantitybutton.alpha = 1
            minusButton.alpha = 1
            
            itemDescription.resignFirstResponder()
            itemName.resignFirstResponder()
            
            
            
            
            
            
            
            
        }else{
            
            
            
            
        }
        
    }
    
    
    @IBAction func secondAddButtonTapped(sender: AnyObject) {
        
        newItem.setObject(quantity, forKey: "quantity")
        
        
        let query = PFQuery(className: "Group")
        
        query.whereKey("objectId2", equalTo: PFUser.currentUser()!.objectId!)
        
        query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
            if error == nil && objects != nil{
                let obj = (objects as! [PFObject]).first!
                
                self.newItem.setObject(obj.objectId!, forKey: "group")
                
                self.newItem.save()
                
                self.addButtonasLabel.alpha = 1
                self.descriptionLabel.alpha = 1
                self.itemNameLabel.alpha = 1
                self.itemName.alpha = 1
                self.itemDescription.alpha = 1
                
                self.quantityLabel.alpha = 0
                self.addbutton2.alpha = 0
                self.backButton.alpha = 0
                self.quantyityTextField.alpha = 0
                self.addquantitybutton.alpha = 0
                self.minusButton.alpha = 0
                
                self.itemName.resignFirstResponder()
                self.itemDescription.resignFirstResponder()
                self.bottomConstraint.constant = -140
                self.itemName.text = ""
                self.itemDescription.text = ""
            }
        }
        
        
        
    }
    
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        
        addButtonasLabel.alpha = 1
        descriptionLabel.alpha = 1
        itemNameLabel.alpha = 1
        itemName.alpha = 1
        itemDescription.alpha = 1
        
        quantityLabel.alpha = 0
        addbutton2.alpha = 0
        backButton.alpha = 0
        quantyityTextField.alpha = 0
        addquantitybutton.alpha = 0
        minusButton.alpha = 0
        
    }
    
    
    @IBAction func addQuantityTapped(sender: AnyObject) {
        
        
        if quantity == 99 {
            
        }else{
            quantity++
        }
        quantyityTextField.text = "\(quantity)"
        
    }
    
    
    @IBAction func minusQuantityTapped(sender: AnyObject) {
        
        
        if quantity == 1 {
            
        }else{
            quantity--
        }
        quantyityTextField.text = "\(quantity)"
        
    }
    
    
    
    
    
    
    
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textViewDidChange(textView: UITextView) {
        if textView.text.containsString("\n") {
            bottomConstraint.constant = 0
            itemDescription.resignFirstResponder()
        }
    }
    
    func textFieldDidBeginEditing(textField: UITextField) {
        bottomConstraint.constant = 225
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        bottomConstraint.constant = 225
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        
        bottomConstraint.constant = 0
    }
    func textViewDidEndEditing(textView: UITextView) {
        bottomConstraint.constant = 0
    }
    
    
    
    
    
    
    func makeGradient(){
        
        let topColor = UIColor(colorLiteralRed: 202/255, green: 202/255, blue: 202/255, alpha: 1)
        
        let bottomColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.CGColor, bottomColor.CGColor]
        
        let gradientLocations: [Float] = [0.0,1.0]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        gradientLayer.frame = self.view.bounds
        self.view.layer.insertSublayer(gradientLayer, atIndex: 0)
        
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if groupList.count == 0 {
            groupListsTableView.alpha = 0
            //show instructions image
        }else{
            groupListsTableView.alpha = 1
        }
        return groupList.count
    }
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = groupListsTableView.dequeueReusableCellWithIdentifier("groupListCell") as! GroupListCell
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        cell.groupListName.text = groupList[indexPath.row].groupName
        cell.groupListDescription.text = groupList[indexPath.row].groupDescription
        cell.groupListImage.image = groupList[indexPath.row].groupImage
        cell.groupListMemberCount.text = "\(groupList[indexPath.row].members.count) members"
        
        return cell
    }
    
    
    var num = 0
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        num = indexPath.row
        performSegueWithIdentifier("maintogroup", sender: self)
    }
    
    
    
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .Normal, title: "delete") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "delete")
        }
        delete.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        let exit = UITableViewRowAction(style: .Normal, title: " exit ") { action, index in
            self.doAction(tableView, indexPath: indexPath, type: "exit")
        }
        exit.backgroundColor = UIColor(red: 202/255, green: 202/255, blue: 202/255, alpha: 0.50)
        
        if groupList[indexPath.row].creator == PFUser.currentUser()!.username! {
            return [delete]
        }else{
            return [exit]
        }
        
    }
    
    
    
    func doAction(tableView: UITableView, indexPath: NSIndexPath, type: String) {
        
        if type == "delete" {
            
            let query = PFQuery(className: "Group")
            
            query.whereKey("objectId", equalTo: groupList[indexPath.row].objectId)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    obj.setValue(false, forKey: "editable")
                    
                    obj.save()
                    
                    self.groupListsTableView.reloadData()
                }
                
                
            }
        }
        if type == "exit" {
            
            let query = PFQuery(className: "Group")
            
            query.whereKey("objectId", equalTo: groupList[indexPath.row].objectId)
            
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil && objects != nil{
                    let obj = (objects as! [PFObject]).first!
                    
                    var joe : [String] = obj.valueForKey("members") as! [String]
                    
                    joe.removeAtIndex(joe.indexOf(PFUser.currentUser()!.username!)!)
                    
                    obj.setValue(joe, forKey: "members")
                    
                    obj.save()
                    
                    
                }
                
                
            }
            self.groupListsTableView.reloadData()
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "maintogroup" {
            
            let nextViewController = segue.destinationViewController as! GroupViewController
            
            nextViewController.selectedGroup = groupList[num]
            
        }
    }
    
    func iconTapped(){
        performSegueWithIdentifier("maintoabout", sender: self)
        
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        return textView.text.characters.count + (text.characters.count - range.length) <= 30
    }
    
    @IBAction func myListButtonTapped(sender: AnyObject) {
        performSegueWithIdentifier("maintomylist", sender: self)
    }
    
    @IBAction func settingsButtonTapped(sender: AnyObject) {
         performSegueWithIdentifier("maintosettings", sender: self)
        // screen doesnt have a back button so im disabling it for mow
    }
    
    @IBAction func newListButtonTapped(sender: AnyObject) {
        performSegueWithIdentifier("maintofirstnewgroup", sender: self)
    }
    
    
    @IBAction func newNoteButtonTapped(sender: AnyObject) {
        bottomConstraint.constant = 0
        itemName.becomeFirstResponder()
    }

}

